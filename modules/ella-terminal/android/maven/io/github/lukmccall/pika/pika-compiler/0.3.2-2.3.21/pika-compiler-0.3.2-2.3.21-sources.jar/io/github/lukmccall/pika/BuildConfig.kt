package io.github.lukmccall.pika

import kotlin.String

internal object BuildConfig {
  internal const val KOTLIN_PLUGIN_ID: String = "io.github.lukmccall.pika"
}
